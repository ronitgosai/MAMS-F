import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-raw-material-report',
  templateUrl: './raw-material-report.component.html',
  styleUrls: ['./raw-material-report.component.scss']
})
export class RawMaterialReportComponent implements OnInit {

  constructor(
  ) {}

  ngOnInit(): void {
  }
}