export interface IUser {
    // login_id: string;
    login_username: string;
    login_password: string;
    // login_role: string;
    // login_mobile: number;
    // female: string;
    // other: string;
    // password: string;
    // cart: string[];
    // favourite: string[];
  }
  
  export class User implements IUser {
    login_username: string;
    login_password: string;
    // lastName: string;
    // email: string;
    // mobile: number;
    // address: string;
    // male: string;
    // female: string;
    // other: string;
    // password: string;
    // cart: string[];
    // favourite: string[];
  }
  