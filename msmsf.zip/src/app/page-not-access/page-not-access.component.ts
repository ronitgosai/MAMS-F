import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-not-access',
  templateUrl: './page-not-access.component.html',
  styleUrls: ['./page-not-access.component.scss']
})
export class PageNotAccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
