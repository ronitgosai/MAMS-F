import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advance-salary-report',
  templateUrl: './advance-salary-report.component.html',
  styleUrls: ['./advance-salary-report.component.scss']
})
export class AdvanceSalaryReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
