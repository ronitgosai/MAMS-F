import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salary-report',
  templateUrl: './salary-report.component.html',
  styleUrls: ['./salary-report.component.scss']
})
export class SalaryReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
